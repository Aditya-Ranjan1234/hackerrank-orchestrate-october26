# Public trace snapshot

Derived from the historical local agent-trace.zip for GitHub publication. Credential-shaped strings are redacted, including strings inside recorded commands. This remains an earlier session snapshot; later work is recorded in the root log.txt. The original archive is preserved locally and is excluded from Git.
