# Step-level gold diff

Source: `D:\Hackerrank Orchestrate\hackerrank-orchestrate-october26\code\.cache\step_diff_current_sample.csv` vs `D:\Hackerrank Orchestrate\hackerrank-orchestrate-october26\dataset\sample_output.csv`. Cases: 32. Exact step arrays: 13/32.

## 1. Aggregate mismatch counts
| mismatch_type | count | % of all mismatches |
|---|---:|---:|
| COUNT_MISMATCH | 25 | 17.48% |
| PHASE_ORDER_MISMATCH | 0 | 0.00% |
| OPERATION_MISMATCH | 25 | 17.48% |
| STATE_MISMATCH | 25 | 17.48% |
| SYSTEM_ID_MISMATCH | 34 | 23.78% |
| RESOURCE_ID_MISMATCH | 34 | 23.78% |
| EVIDENCE_ID_MISMATCH_SHOULD_CITE | 0 | 0.00% |
| EVIDENCE_ID_MISMATCH_SHOULD_BE_EMPTY | 0 | 0.00% |
| EVIDENCE_ID_MISMATCH_WRONG_CITATION | 0 | 0.00% |
| STEP_NO_MISMATCH | 0 | 0.00% |

### Position-independent diagnosis
| semantic difference | count |
|---|---:|
| MISSING_SEMANTIC_STEP | 25 |
| EXTRA_SEMANTIC_STEP | 0 |
| EVIDENCE_CITATION_DIFFERENCE | 0 |

### Every sample case
| case | status match | exact array | missing resource/operation steps | extra steps | citation differences |
|---|---|---|---:|---:|---:|
| case_01 | yes | no | 1 | 0 | 0 |
| case_02 | yes | no | 1 | 0 | 0 |
| case_03 | yes | no | 1 | 0 | 0 |
| case_04 | yes | no | 2 | 0 | 0 |
| case_05 | yes | yes | 0 | 0 | 0 |
| case_06 | yes | yes | 0 | 0 | 0 |
| case_07 | yes | no | 1 | 0 | 0 |
| case_08 | yes | no | 1 | 0 | 0 |
| case_09 | yes | yes | 0 | 0 | 0 |
| case_10 | yes | no | 1 | 0 | 0 |
| case_11 | yes | yes | 0 | 0 | 0 |
| case_12 | yes | yes | 0 | 0 | 0 |
| case_13 | yes | yes | 0 | 0 | 0 |
| case_14 | yes | yes | 0 | 0 | 0 |
| case_15 | yes | yes | 0 | 0 | 0 |
| case_16 | yes | yes | 0 | 0 | 0 |
| case_17 | yes | yes | 0 | 0 | 0 |
| case_18 | yes | no | 2 | 0 | 0 |
| case_19 | yes | yes | 0 | 0 | 0 |
| case_20 | yes | no | 2 | 0 | 0 |
| case_21 | yes | no | 2 | 0 | 0 |
| case_22 | yes | no | 1 | 0 | 0 |
| case_23 | yes | no | 1 | 0 | 0 |
| case_24 | yes | yes | 0 | 0 | 0 |
| case_25 | yes | no | 2 | 0 | 0 |
| case_26 | yes | no | 1 | 0 | 0 |
| case_27 | yes | no | 1 | 0 | 0 |
| case_28 | yes | no | 2 | 0 | 0 |
| case_29 | yes | no | 1 | 0 | 0 |
| case_30 | yes | yes | 0 | 0 | 0 |
| case_31 | yes | no | 1 | 0 | 0 |
| case_32 | yes | no | 1 | 0 | 0 |

## 2. Dominant mismatch type
SYSTEM_ID_MISMATCH: 34/143 (23.78%).

## 3. Five largest per-case diffs

### case_29: ours INCOMPLETE (13), gold INCOMPLETE (14)
Our steps:
```json
[
  {
    "step_no": 1,
    "phase": "FINDING",
    "system_id": "search_service",
    "resource_id": "search_1993",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 2,
    "phase": "FINDING",
    "system_id": "analytics_platform",
    "resource_id": "analytics_5208",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 3,
    "phase": "FINDING",
    "system_id": "support_platform",
    "resource_id": "support_5281",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 4,
    "phase": "FINDING",
    "system_id": "integration_service",
    "resource_id": "data_flow_3827",
    "operation": "REPORT_ACTIVE_DATA_FLOW",
    "state": "ACTIVE",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 5,
    "phase": "REMEDIATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_3827",
    "operation": "DISABLE_DATA_FLOW",
    "state": "DISABLED",
    "evidence_id": ""
  },
  {
    "step_no": 6,
    "phase": "REMEDIATION",
    "system_id": "search_service",
    "resource_id": "search_1993",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 7,
    "phase": "REMEDIATION",
    "system_id": "support_platform",
    "resource_id": "support_5281",
    "operation": "REDACT_RECORD",
    "state": "REDACTED",
    "evidence_id": ""
  },
  {
    "step_no": 8,
    "phase": "REMEDIATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_5208",
    "operation": "ANONYMIZE_RECORD",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 9,
    "phase": "VERIFICATION",
    "system_id": "search_service",
    "resource_id": "search_1993",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 10,
    "phase": "VERIFICATION",
    "system_id": "security_service",
    "resource_id": "audit_record_3954",
    "operation": "VERIFY_RECORD_PRESENT",
    "state": "PRESENT",
    "evidence_id": ""
  },
  {
    "step_no": 11,
    "phase": "VERIFICATION",
    "system_id": "support_platform",
    "resource_id": "support_5281",
    "operation": "VERIFY_RECORD_REDACTED",
    "state": "REDACTED",
    "evidence_id": ""
  },
  {
    "step_no": 12,
    "phase": "VERIFICATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_5208",
    "operation": "VERIFY_RECORD_ANONYMIZED",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 13,
    "phase": "VERIFICATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_3827",
    "operation": "VERIFY_DATA_FLOW_DISABLED",
    "state": "DISABLED",
    "evidence_id": ""
  }
]
```
Gold steps:
```json
[
  {
    "step_no": 1,
    "phase": "FINDING",
    "system_id": "search_service",
    "resource_id": "search_1993",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 2,
    "phase": "FINDING",
    "system_id": "analytics_platform",
    "resource_id": "analytics_5208",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 3,
    "phase": "FINDING",
    "system_id": "support_platform",
    "resource_id": "support_5281",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 4,
    "phase": "FINDING",
    "system_id": "integration_service",
    "resource_id": "data_flow_3827",
    "operation": "REPORT_ACTIVE_DATA_FLOW",
    "state": "ACTIVE",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 5,
    "phase": "REMEDIATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_3827",
    "operation": "DISABLE_DATA_FLOW",
    "state": "DISABLED",
    "evidence_id": ""
  },
  {
    "step_no": 6,
    "phase": "REMEDIATION",
    "system_id": "search_service",
    "resource_id": "search_1993",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 7,
    "phase": "REMEDIATION",
    "system_id": "support_platform",
    "resource_id": "support_5281",
    "operation": "REDACT_RECORD",
    "state": "REDACTED",
    "evidence_id": ""
  },
  {
    "step_no": 8,
    "phase": "REMEDIATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_5208",
    "operation": "ANONYMIZE_RECORD",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 9,
    "phase": "VERIFICATION",
    "system_id": "account_service",
    "resource_id": "account_7012",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 10,
    "phase": "VERIFICATION",
    "system_id": "search_service",
    "resource_id": "search_1993",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 11,
    "phase": "VERIFICATION",
    "system_id": "security_service",
    "resource_id": "audit_record_3954",
    "operation": "VERIFY_RECORD_PRESENT",
    "state": "PRESENT",
    "evidence_id": ""
  },
  {
    "step_no": 12,
    "phase": "VERIFICATION",
    "system_id": "support_platform",
    "resource_id": "support_5281",
    "operation": "VERIFY_RECORD_REDACTED",
    "state": "REDACTED",
    "evidence_id": ""
  },
  {
    "step_no": 13,
    "phase": "VERIFICATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_5208",
    "operation": "VERIFY_RECORD_ANONYMIZED",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 14,
    "phase": "VERIFICATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_3827",
    "operation": "VERIFY_DATA_FLOW_DISABLED",
    "state": "DISABLED",
    "evidence_id": ""
  }
]
```
Differences:
```json
[
  {
    "step_index": 8,
    "field": "system_id",
    "our_value": "search_service",
    "gold_value": "account_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 8,
    "field": "resource_id",
    "our_value": "search_1993",
    "gold_value": "account_7012",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 9,
    "field": "system_id",
    "our_value": "security_service",
    "gold_value": "search_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 9,
    "field": "resource_id",
    "our_value": "audit_record_3954",
    "gold_value": "search_1993",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 9,
    "field": "operation",
    "our_value": "VERIFY_RECORD_PRESENT",
    "gold_value": "VERIFY_RECORD_ABSENT",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 9,
    "field": "state",
    "our_value": "PRESENT",
    "gold_value": "ABSENT",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 10,
    "field": "system_id",
    "our_value": "support_platform",
    "gold_value": "security_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 10,
    "field": "resource_id",
    "our_value": "support_5281",
    "gold_value": "audit_record_3954",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 10,
    "field": "operation",
    "our_value": "VERIFY_RECORD_REDACTED",
    "gold_value": "VERIFY_RECORD_PRESENT",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 10,
    "field": "state",
    "our_value": "REDACTED",
    "gold_value": "PRESENT",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 11,
    "field": "system_id",
    "our_value": "analytics_platform",
    "gold_value": "support_platform",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 11,
    "field": "resource_id",
    "our_value": "analytics_5208",
    "gold_value": "support_5281",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 11,
    "field": "operation",
    "our_value": "VERIFY_RECORD_ANONYMIZED",
    "gold_value": "VERIFY_RECORD_REDACTED",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 11,
    "field": "state",
    "our_value": "ANONYMIZED",
    "gold_value": "REDACTED",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 12,
    "field": "system_id",
    "our_value": "integration_service",
    "gold_value": "analytics_platform",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 12,
    "field": "resource_id",
    "our_value": "data_flow_3827",
    "gold_value": "analytics_5208",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 12,
    "field": "operation",
    "our_value": "VERIFY_DATA_FLOW_DISABLED",
    "gold_value": "VERIFY_RECORD_ANONYMIZED",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 12,
    "field": "state",
    "our_value": "DISABLED",
    "gold_value": "ANONYMIZED",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 13,
    "field": "step",
    "our_value": null,
    "gold_value": {
      "step_no": 14,
      "phase": "VERIFICATION",
      "system_id": "integration_service",
      "resource_id": "data_flow_3827",
      "operation": "VERIFY_DATA_FLOW_DISABLED",
      "state": "DISABLED",
      "evidence_id": ""
    },
    "mismatch_type": "COUNT_MISMATCH"
  }
]
```

### case_28: ours COMPLETE (4), gold COMPLETE (6)
Our steps:
```json
[
  {
    "step_no": 1,
    "phase": "VERIFICATION",
    "system_id": "security_service",
    "resource_id": "audit_record_9265",
    "operation": "VERIFY_RECORD_PRESENT",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 2,
    "phase": "VERIFICATION",
    "system_id": "support_platform",
    "resource_id": "support_2351",
    "operation": "VERIFY_RECORD_REDACTED",
    "state": "REDACTED",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 3,
    "phase": "VERIFICATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_2337",
    "operation": "VERIFY_DATA_FLOW_DISABLED",
    "state": "DISABLED",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 4,
    "phase": "VERIFICATION",
    "system_id": "backup_service",
    "resource_id": "backup_838",
    "operation": "VERIFY_RESTORE_BLOCKED",
    "state": "BLOCKED",
    "evidence_id": "evidence_92"
  }
]
```
Gold steps:
```json
[
  {
    "step_no": 1,
    "phase": "VERIFICATION",
    "system_id": "account_service",
    "resource_id": "account_5482",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 2,
    "phase": "VERIFICATION",
    "system_id": "security_service",
    "resource_id": "audit_record_9265",
    "operation": "VERIFY_RECORD_PRESENT",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 3,
    "phase": "VERIFICATION",
    "system_id": "support_platform",
    "resource_id": "support_2351",
    "operation": "VERIFY_RECORD_REDACTED",
    "state": "REDACTED",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 4,
    "phase": "VERIFICATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_6077",
    "operation": "VERIFY_RECORD_ANONYMIZED",
    "state": "ANONYMIZED",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 5,
    "phase": "VERIFICATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_2337",
    "operation": "VERIFY_DATA_FLOW_DISABLED",
    "state": "DISABLED",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 6,
    "phase": "VERIFICATION",
    "system_id": "backup_service",
    "resource_id": "backup_838",
    "operation": "VERIFY_RESTORE_BLOCKED",
    "state": "BLOCKED",
    "evidence_id": "evidence_92"
  }
]
```
Differences:
```json
[
  {
    "step_index": 0,
    "field": "system_id",
    "our_value": "security_service",
    "gold_value": "account_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 0,
    "field": "resource_id",
    "our_value": "audit_record_9265",
    "gold_value": "account_5482",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 0,
    "field": "operation",
    "our_value": "VERIFY_RECORD_PRESENT",
    "gold_value": "VERIFY_RECORD_ABSENT",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 0,
    "field": "state",
    "our_value": "PRESENT",
    "gold_value": "ABSENT",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 1,
    "field": "system_id",
    "our_value": "support_platform",
    "gold_value": "security_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 1,
    "field": "resource_id",
    "our_value": "support_2351",
    "gold_value": "audit_record_9265",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 1,
    "field": "operation",
    "our_value": "VERIFY_RECORD_REDACTED",
    "gold_value": "VERIFY_RECORD_PRESENT",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 1,
    "field": "state",
    "our_value": "REDACTED",
    "gold_value": "PRESENT",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 2,
    "field": "system_id",
    "our_value": "integration_service",
    "gold_value": "support_platform",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 2,
    "field": "resource_id",
    "our_value": "data_flow_2337",
    "gold_value": "support_2351",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 2,
    "field": "operation",
    "our_value": "VERIFY_DATA_FLOW_DISABLED",
    "gold_value": "VERIFY_RECORD_REDACTED",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 2,
    "field": "state",
    "our_value": "DISABLED",
    "gold_value": "REDACTED",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 3,
    "field": "system_id",
    "our_value": "backup_service",
    "gold_value": "analytics_platform",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 3,
    "field": "resource_id",
    "our_value": "backup_838",
    "gold_value": "analytics_6077",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 3,
    "field": "operation",
    "our_value": "VERIFY_RESTORE_BLOCKED",
    "gold_value": "VERIFY_RECORD_ANONYMIZED",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 3,
    "field": "state",
    "our_value": "BLOCKED",
    "gold_value": "ANONYMIZED",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 4,
    "field": "step",
    "our_value": null,
    "gold_value": {
      "step_no": 5,
      "phase": "VERIFICATION",
      "system_id": "integration_service",
      "resource_id": "data_flow_2337",
      "operation": "VERIFY_DATA_FLOW_DISABLED",
      "state": "DISABLED",
      "evidence_id": "evidence_92"
    },
    "mismatch_type": "COUNT_MISMATCH"
  },
  {
    "step_index": 5,
    "field": "step",
    "our_value": null,
    "gold_value": {
      "step_no": 6,
      "phase": "VERIFICATION",
      "system_id": "backup_service",
      "resource_id": "backup_838",
      "operation": "VERIFY_RESTORE_BLOCKED",
      "state": "BLOCKED",
      "evidence_id": "evidence_92"
    },
    "mismatch_type": "COUNT_MISMATCH"
  }
]
```

### case_18: ours INCOMPLETE (12), gold INCOMPLETE (14)
Our steps:
```json
[
  {
    "step_no": 1,
    "phase": "FINDING",
    "system_id": "search_service",
    "resource_id": "search_4013",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_94"
  },
  {
    "step_no": 2,
    "phase": "FINDING",
    "system_id": "analytics_platform",
    "resource_id": "analytics_037",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_94"
  },
  {
    "step_no": 3,
    "phase": "FINDING",
    "system_id": "support_platform",
    "resource_id": "support_5569",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_94"
  },
  {
    "step_no": 4,
    "phase": "FINDING",
    "system_id": "integration_service",
    "resource_id": "data_flow_4890",
    "operation": "REPORT_ACTIVE_DATA_FLOW",
    "state": "ACTIVE",
    "evidence_id": "evidence_94"
  },
  {
    "step_no": 5,
    "phase": "REMEDIATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_4890",
    "operation": "DISABLE_DATA_FLOW",
    "state": "DISABLED",
    "evidence_id": ""
  },
  {
    "step_no": 6,
    "phase": "REMEDIATION",
    "system_id": "search_service",
    "resource_id": "search_4013",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 7,
    "phase": "REMEDIATION",
    "system_id": "support_platform",
    "resource_id": "support_5569",
    "operation": "REDACT_RECORD",
    "state": "REDACTED",
    "evidence_id": ""
  },
  {
    "step_no": 8,
    "phase": "REMEDIATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_037",
    "operation": "ANONYMIZE_RECORD",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 9,
    "phase": "VERIFICATION",
    "system_id": "search_service",
    "resource_id": "search_4013",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 10,
    "phase": "VERIFICATION",
    "system_id": "support_platform",
    "resource_id": "support_5569",
    "operation": "VERIFY_RECORD_REDACTED",
    "state": "REDACTED",
    "evidence_id": ""
  },
  {
    "step_no": 11,
    "phase": "VERIFICATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_037",
    "operation": "VERIFY_RECORD_ANONYMIZED",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 12,
    "phase": "VERIFICATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_4890",
    "operation": "VERIFY_DATA_FLOW_DISABLED",
    "state": "DISABLED",
    "evidence_id": ""
  }
]
```
Gold steps:
```json
[
  {
    "step_no": 1,
    "phase": "FINDING",
    "system_id": "search_service",
    "resource_id": "search_4013",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_94"
  },
  {
    "step_no": 2,
    "phase": "FINDING",
    "system_id": "analytics_platform",
    "resource_id": "analytics_037",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_94"
  },
  {
    "step_no": 3,
    "phase": "FINDING",
    "system_id": "support_platform",
    "resource_id": "support_5569",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_94"
  },
  {
    "step_no": 4,
    "phase": "FINDING",
    "system_id": "integration_service",
    "resource_id": "data_flow_4890",
    "operation": "REPORT_ACTIVE_DATA_FLOW",
    "state": "ACTIVE",
    "evidence_id": "evidence_94"
  },
  {
    "step_no": 5,
    "phase": "REMEDIATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_4890",
    "operation": "DISABLE_DATA_FLOW",
    "state": "DISABLED",
    "evidence_id": ""
  },
  {
    "step_no": 6,
    "phase": "REMEDIATION",
    "system_id": "search_service",
    "resource_id": "search_4013",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 7,
    "phase": "REMEDIATION",
    "system_id": "support_platform",
    "resource_id": "support_5569",
    "operation": "REDACT_RECORD",
    "state": "REDACTED",
    "evidence_id": ""
  },
  {
    "step_no": 8,
    "phase": "REMEDIATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_037",
    "operation": "ANONYMIZE_RECORD",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 9,
    "phase": "VERIFICATION",
    "system_id": "account_service",
    "resource_id": "account_5521",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 10,
    "phase": "VERIFICATION",
    "system_id": "search_service",
    "resource_id": "search_4013",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 11,
    "phase": "VERIFICATION",
    "system_id": "security_service",
    "resource_id": "audit_record_6645",
    "operation": "VERIFY_RECORD_PRESENT",
    "state": "PRESENT",
    "evidence_id": ""
  },
  {
    "step_no": 12,
    "phase": "VERIFICATION",
    "system_id": "support_platform",
    "resource_id": "support_5569",
    "operation": "VERIFY_RECORD_REDACTED",
    "state": "REDACTED",
    "evidence_id": ""
  },
  {
    "step_no": 13,
    "phase": "VERIFICATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_037",
    "operation": "VERIFY_RECORD_ANONYMIZED",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 14,
    "phase": "VERIFICATION",
    "system_id": "integration_service",
    "resource_id": "data_flow_4890",
    "operation": "VERIFY_DATA_FLOW_DISABLED",
    "state": "DISABLED",
    "evidence_id": ""
  }
]
```
Differences:
```json
[
  {
    "step_index": 8,
    "field": "system_id",
    "our_value": "search_service",
    "gold_value": "account_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 8,
    "field": "resource_id",
    "our_value": "search_4013",
    "gold_value": "account_5521",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 9,
    "field": "system_id",
    "our_value": "support_platform",
    "gold_value": "search_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 9,
    "field": "resource_id",
    "our_value": "support_5569",
    "gold_value": "search_4013",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 9,
    "field": "operation",
    "our_value": "VERIFY_RECORD_REDACTED",
    "gold_value": "VERIFY_RECORD_ABSENT",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 9,
    "field": "state",
    "our_value": "REDACTED",
    "gold_value": "ABSENT",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 10,
    "field": "system_id",
    "our_value": "analytics_platform",
    "gold_value": "security_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 10,
    "field": "resource_id",
    "our_value": "analytics_037",
    "gold_value": "audit_record_6645",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 10,
    "field": "operation",
    "our_value": "VERIFY_RECORD_ANONYMIZED",
    "gold_value": "VERIFY_RECORD_PRESENT",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 10,
    "field": "state",
    "our_value": "ANONYMIZED",
    "gold_value": "PRESENT",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 11,
    "field": "system_id",
    "our_value": "integration_service",
    "gold_value": "support_platform",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 11,
    "field": "resource_id",
    "our_value": "data_flow_4890",
    "gold_value": "support_5569",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 11,
    "field": "operation",
    "our_value": "VERIFY_DATA_FLOW_DISABLED",
    "gold_value": "VERIFY_RECORD_REDACTED",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 11,
    "field": "state",
    "our_value": "DISABLED",
    "gold_value": "REDACTED",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 12,
    "field": "step",
    "our_value": null,
    "gold_value": {
      "step_no": 13,
      "phase": "VERIFICATION",
      "system_id": "analytics_platform",
      "resource_id": "analytics_037",
      "operation": "VERIFY_RECORD_ANONYMIZED",
      "state": "ANONYMIZED",
      "evidence_id": ""
    },
    "mismatch_type": "COUNT_MISMATCH"
  },
  {
    "step_index": 13,
    "field": "step",
    "our_value": null,
    "gold_value": {
      "step_no": 14,
      "phase": "VERIFICATION",
      "system_id": "integration_service",
      "resource_id": "data_flow_4890",
      "operation": "VERIFY_DATA_FLOW_DISABLED",
      "state": "DISABLED",
      "evidence_id": ""
    },
    "mismatch_type": "COUNT_MISMATCH"
  }
]
```

### case_22: ours INCOMPLETE (7), gold INCOMPLETE (8)
Our steps:
```json
[
  {
    "step_no": 1,
    "phase": "FINDING",
    "system_id": "search_service",
    "resource_id": "search_8911",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_05"
  },
  {
    "step_no": 2,
    "phase": "FINDING",
    "system_id": "analytics_platform",
    "resource_id": "analytics_4440",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_05"
  },
  {
    "step_no": 3,
    "phase": "REMEDIATION",
    "system_id": "search_service",
    "resource_id": "search_8911",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 4,
    "phase": "REMEDIATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_4440",
    "operation": "ANONYMIZE_RECORD",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 5,
    "phase": "VERIFICATION",
    "system_id": "search_service",
    "resource_id": "search_8911",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 6,
    "phase": "VERIFICATION",
    "system_id": "security_service",
    "resource_id": "audit_record_3482",
    "operation": "VERIFY_RECORD_PRESENT",
    "state": "PRESENT",
    "evidence_id": ""
  },
  {
    "step_no": 7,
    "phase": "VERIFICATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_4440",
    "operation": "VERIFY_RECORD_ANONYMIZED",
    "state": "ANONYMIZED",
    "evidence_id": ""
  }
]
```
Gold steps:
```json
[
  {
    "step_no": 1,
    "phase": "FINDING",
    "system_id": "search_service",
    "resource_id": "search_8911",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_05"
  },
  {
    "step_no": 2,
    "phase": "FINDING",
    "system_id": "analytics_platform",
    "resource_id": "analytics_4440",
    "operation": "REPORT_EXPOSED_PII",
    "state": "PRESENT",
    "evidence_id": "evidence_05"
  },
  {
    "step_no": 3,
    "phase": "REMEDIATION",
    "system_id": "search_service",
    "resource_id": "search_8911",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 4,
    "phase": "REMEDIATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_4440",
    "operation": "ANONYMIZE_RECORD",
    "state": "ANONYMIZED",
    "evidence_id": ""
  },
  {
    "step_no": 5,
    "phase": "VERIFICATION",
    "system_id": "account_service",
    "resource_id": "account_4990",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 6,
    "phase": "VERIFICATION",
    "system_id": "search_service",
    "resource_id": "search_8911",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 7,
    "phase": "VERIFICATION",
    "system_id": "security_service",
    "resource_id": "audit_record_3482",
    "operation": "VERIFY_RECORD_PRESENT",
    "state": "PRESENT",
    "evidence_id": ""
  },
  {
    "step_no": 8,
    "phase": "VERIFICATION",
    "system_id": "analytics_platform",
    "resource_id": "analytics_4440",
    "operation": "VERIFY_RECORD_ANONYMIZED",
    "state": "ANONYMIZED",
    "evidence_id": ""
  }
]
```
Differences:
```json
[
  {
    "step_index": 4,
    "field": "system_id",
    "our_value": "search_service",
    "gold_value": "account_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 4,
    "field": "resource_id",
    "our_value": "search_8911",
    "gold_value": "account_4990",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 5,
    "field": "system_id",
    "our_value": "security_service",
    "gold_value": "search_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 5,
    "field": "resource_id",
    "our_value": "audit_record_3482",
    "gold_value": "search_8911",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 5,
    "field": "operation",
    "our_value": "VERIFY_RECORD_PRESENT",
    "gold_value": "VERIFY_RECORD_ABSENT",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 5,
    "field": "state",
    "our_value": "PRESENT",
    "gold_value": "ABSENT",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 6,
    "field": "system_id",
    "our_value": "analytics_platform",
    "gold_value": "security_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 6,
    "field": "resource_id",
    "our_value": "analytics_4440",
    "gold_value": "audit_record_3482",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 6,
    "field": "operation",
    "our_value": "VERIFY_RECORD_ANONYMIZED",
    "gold_value": "VERIFY_RECORD_PRESENT",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 6,
    "field": "state",
    "our_value": "ANONYMIZED",
    "gold_value": "PRESENT",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 7,
    "field": "step",
    "our_value": null,
    "gold_value": {
      "step_no": 8,
      "phase": "VERIFICATION",
      "system_id": "analytics_platform",
      "resource_id": "analytics_4440",
      "operation": "VERIFY_RECORD_ANONYMIZED",
      "state": "ANONYMIZED",
      "evidence_id": ""
    },
    "mismatch_type": "COUNT_MISMATCH"
  }
]
```

### case_23: ours INCOMPLETE (7), gold INCOMPLETE (8)
Our steps:
```json
[
  {
    "step_no": 1,
    "phase": "FINDING",
    "system_id": "export_service",
    "resource_id": "export_7364",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 2,
    "phase": "FINDING",
    "system_id": "search_service",
    "resource_id": "search_898",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 3,
    "phase": "REMEDIATION",
    "system_id": "export_service",
    "resource_id": "export_7364",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 4,
    "phase": "REMEDIATION",
    "system_id": "search_service",
    "resource_id": "search_898",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 5,
    "phase": "VERIFICATION",
    "system_id": "export_service",
    "resource_id": "export_7364",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 6,
    "phase": "VERIFICATION",
    "system_id": "search_service",
    "resource_id": "search_898",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 7,
    "phase": "VERIFICATION",
    "system_id": "security_service",
    "resource_id": "audit_record_4128",
    "operation": "VERIFY_RECORD_PRESENT",
    "state": "PRESENT",
    "evidence_id": ""
  }
]
```
Gold steps:
```json
[
  {
    "step_no": 1,
    "phase": "FINDING",
    "system_id": "export_service",
    "resource_id": "export_7364",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 2,
    "phase": "FINDING",
    "system_id": "search_service",
    "resource_id": "search_898",
    "operation": "REPORT_REMAINING_RECORD",
    "state": "PRESENT",
    "evidence_id": "evidence_92"
  },
  {
    "step_no": 3,
    "phase": "REMEDIATION",
    "system_id": "export_service",
    "resource_id": "export_7364",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 4,
    "phase": "REMEDIATION",
    "system_id": "search_service",
    "resource_id": "search_898",
    "operation": "DELETE_RECORD",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 5,
    "phase": "VERIFICATION",
    "system_id": "account_service",
    "resource_id": "account_410",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 6,
    "phase": "VERIFICATION",
    "system_id": "export_service",
    "resource_id": "export_7364",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 7,
    "phase": "VERIFICATION",
    "system_id": "search_service",
    "resource_id": "search_898",
    "operation": "VERIFY_RECORD_ABSENT",
    "state": "ABSENT",
    "evidence_id": ""
  },
  {
    "step_no": 8,
    "phase": "VERIFICATION",
    "system_id": "security_service",
    "resource_id": "audit_record_4128",
    "operation": "VERIFY_RECORD_PRESENT",
    "state": "PRESENT",
    "evidence_id": ""
  }
]
```
Differences:
```json
[
  {
    "step_index": 4,
    "field": "system_id",
    "our_value": "export_service",
    "gold_value": "account_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 4,
    "field": "resource_id",
    "our_value": "export_7364",
    "gold_value": "account_410",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 5,
    "field": "system_id",
    "our_value": "search_service",
    "gold_value": "export_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 5,
    "field": "resource_id",
    "our_value": "search_898",
    "gold_value": "export_7364",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 6,
    "field": "system_id",
    "our_value": "security_service",
    "gold_value": "search_service",
    "mismatch_type": "SYSTEM_ID_MISMATCH"
  },
  {
    "step_index": 6,
    "field": "resource_id",
    "our_value": "audit_record_4128",
    "gold_value": "search_898",
    "mismatch_type": "RESOURCE_ID_MISMATCH"
  },
  {
    "step_index": 6,
    "field": "operation",
    "our_value": "VERIFY_RECORD_PRESENT",
    "gold_value": "VERIFY_RECORD_ABSENT",
    "mismatch_type": "OPERATION_MISMATCH"
  },
  {
    "step_index": 6,
    "field": "state",
    "our_value": "PRESENT",
    "gold_value": "ABSENT",
    "mismatch_type": "STATE_MISMATCH"
  },
  {
    "step_index": 7,
    "field": "step",
    "our_value": null,
    "gold_value": {
      "step_no": 8,
      "phase": "VERIFICATION",
      "system_id": "security_service",
      "resource_id": "audit_record_4128",
      "operation": "VERIFY_RECORD_PRESENT",
      "state": "PRESENT",
      "evidence_id": ""
    },
    "mismatch_type": "COUNT_MISMATCH"
  }
]
```

## 4. Hypothesis
Likely upstream system attribution, not Phase 6.
Position-independent exact step identities shared: 168; ours: 168; gold: 193. This excludes `step_no` and does not treat shifted positions as mapping errors.

## 5. Recommendation
Compare step identities independent of index, then trace the first incorrect verdict. A positional mismatch can be caused by upstream extra/missing resources; do not assume Phase 6 is defective from 0 exact arrays alone.
