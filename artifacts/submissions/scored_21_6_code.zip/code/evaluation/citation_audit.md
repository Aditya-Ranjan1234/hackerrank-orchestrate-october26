# Output citation source audit

Checks the generated `output.csv` against the evidence manifest, activity IDs and identity audit IDs. It never opens `sample_output.csv`. For an evidence-file citation, the complete resource ID must be visible in that file's text, PDF extraction or local image OCR. Generated log-line handles are accepted only when the cited line exists and contains an exact identifier for the case. Image OCR gaps can be false negatives and require visual review.
A separate count identifies citations to files captured after audit_at. Such files may contain older timestamped observations; their capture date alone does not tell whether the cited row reflects audit-time state. Review this count when applying the repository's evidence cutoff rule.

| Measure | Count |
|---|---:|
| activity_citations | 48 |
| cited_steps | 952 |
| evidence_file_citations | 904 |
| retrospectively_captured_file_citations | 29 |
| source_files_opened | 70 |

Potential citation issues: 0.

| case | citation | resource | issue |
|---|---|---|---|
