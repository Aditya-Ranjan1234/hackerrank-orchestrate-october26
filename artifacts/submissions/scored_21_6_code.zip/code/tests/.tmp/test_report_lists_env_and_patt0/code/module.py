import openai
import os
x=os.getenv("MY_API_KEY")
