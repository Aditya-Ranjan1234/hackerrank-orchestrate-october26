"""Classify request intent with bounded word stems."""
import re

DELETION_STEM_PATTERNS=[
    r"\bdelet\w*\b",r"\bremov\w*\b",r"\beras\w*\b",r"\b(?:forget|forgot)\w*\b",
    r"\bpurg\w*\b",r"\bdestroy\w*\b",r"\banonymi[sz]\w*\b",r"\bterminat\w*\b",
    r"\bwip\w*\b",r"\bright to erasure\b",r"\bright to be forgotten\b",
    r"\bclose my account\b",r"\bclose the account\b",r"\bclose account\b",
    r"\bpermanently delete\b",r"\bpermanently remove\b",r"\bdeletion\b",
]
NON_DELETION_STEM_PATTERNS=[
    r"\bexport\w*\b",r"\bdownload\w*\b",r"\bview\w*\b",r"\baccess\w*\b",
    r"\bverif\w*\b",r"\bupdat\w*\b",r"\bchang\w*\b",r"\bcorrect\w*\b",
    r"\bamend\w*\b",r"\bmodif\w*\b",r"\bedit\w*\b",r"\bunsubscribe\b",
    r"\bopt[\s-]?out\b",r"\bstop receiving\b",r"\bstop emails\b",
    r"\b(?:merge|split)\w*\b",r"\btransfer ownership\b",
]
_DELETION_REGEX=[re.compile(p,re.I) for p in DELETION_STEM_PATTERNS]
_NON_DELETION_REGEX=[re.compile(p,re.I) for p in NON_DELETION_STEM_PATTERNS]

def matched_keywords(text):
    value=(text or "").strip()
    return [m.group() for regex in _DELETION_REGEX+_NON_DELETION_REGEX if (m:=regex.search(value))]

def is_deletion_request(request_text):
    text=(request_text or "").strip()
    if not text: return True
    deletion=any(r.search(text) for r in _DELETION_REGEX)
    non=any(r.search(text) for r in _NON_DELETION_REGEX)
    return not non or deletion
